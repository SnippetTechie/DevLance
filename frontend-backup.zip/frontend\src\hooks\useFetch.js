import React from 'react'

const useFetch = () => {
  return (
    <div>
      
    </div>
  )
}

export default useFetch
