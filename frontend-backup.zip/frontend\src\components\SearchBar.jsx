import React from 'react'

const SearchBar = () => {
  return (
    <div>
      
    </div>
  )
}

export default SearchBar
