import React from 'react'

const GigDetails = () => {
  return (
    <div>
      
    </div>
  )
}

export default GigDetails
