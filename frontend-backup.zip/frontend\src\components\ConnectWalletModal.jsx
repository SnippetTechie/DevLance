import React from 'react'

const ConnectWalletModal = () => {
  return (
    <div>
      
    </div>
  )
}

export default ConnectWalletModal
