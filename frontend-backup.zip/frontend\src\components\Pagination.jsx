import React from 'react'

const Pagination = () => {
  return (
    <div>
      
    </div>
  )
}

export default Pagination
