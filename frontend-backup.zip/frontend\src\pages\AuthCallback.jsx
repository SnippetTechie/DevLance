import React from 'react'

const AuthCallback = () => {
  return (
    <div>
      
    </div>
  )
}

export default AuthCallback
