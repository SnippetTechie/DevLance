import React from 'react'

const WalletContext = () => {
  return (
    <div>
      
    </div>
  )
}

export default WalletContext
