import React from 'react'

const WalletStatus = () => {
  return (
    <div>
      
    </div>
  )
}

export default WalletStatus
