import React from 'react'

const CreateGig = () => {
  return (
    <div>
      
    </div>
  )
}

export default CreateGig
