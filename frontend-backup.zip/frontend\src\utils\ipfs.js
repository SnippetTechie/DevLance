import React from 'react'

const ipfs = () => {
  return (
    <div>
      
    </div>
  )
}

export default ipfs
